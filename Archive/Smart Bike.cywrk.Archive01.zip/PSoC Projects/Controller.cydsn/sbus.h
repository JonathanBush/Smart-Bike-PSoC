#ifndef SBUS_h
#define SBUS_h


#define SBUS_FAILSAFE_INACTIVE 0
#define SBUS_FAILSAFE_ACTIVE   1
#define SBUS_STARTBYTE         0x0f
#define SBUS_ENDBYTE           0x00




void sbus_begin();
int sbus_getChannel(int channel);
int sbus_getNormalizedChannel(int channel);
int sbus_getFailsafeStatus();
int sbus_getFrameLoss();
long sbus_getGoodFrames();
long sbus_getLostFrames();
long sbus_getDecoderErrorFrames();





#endif