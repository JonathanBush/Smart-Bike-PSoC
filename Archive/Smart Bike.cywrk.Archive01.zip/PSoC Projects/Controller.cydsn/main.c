/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "sbus.h"
#define MIN_THROTTLE_VOLTAGE 0.902
#define MAX_THROTTLE_VOLTAGE 3.659

/* power between 0 and 1 */
void set_throttle(float power);

CY_ISR_PROTO(throttle_handler);

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    //float speed;
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    Throttle_Start();
    //Throttle_Enable();
    
    isr_1_StartEx(throttle_handler);
    //RPi_UART_Start();
    sbus_begin();
    for(;;)
    {
        Throttle_SetValue(sbus_getChannel(1));
        /*for(speed = 0; speed <= 1; speed += .01) {
            set_throttle(speed);
            CyDelay(50);
        }
        for(; speed >= 0; speed -= .01) {
            set_throttle(speed);
            CyDelay(50);
        }*/
        //Throttle_SetValue(255);
    }
}

void set_throttle(float power)
{
    Throttle_SetValue((char)(255.* (((MAX_THROTTLE_VOLTAGE - MIN_THROTTLE_VOLTAGE) * power + MIN_THROTTLE_VOLTAGE)/4.096)));
}

CY_ISR(throttle_handler)
{
    //set_throttle(1.);
    unsigned char data = RPi_UART_ReadRxData();
    set_throttle(((float)data) / 100.);  
    isr_1_ClearPending();
}
/* [] END OF FILE */
